package kr.co.cms.domain.cca.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CcaCompScoreDto {
    private String competency;      // 핵심역량 이름 (예: 의사소통, 문제해결 등)
    private double averageScore;    // 원점수 평균 (1~5)
    private double normalizedScore; // 100점 환산 점수
    private int questionCount;      // 해당 역량 문항 수
}