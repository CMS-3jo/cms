package kr.co.cms.domain.cca.repository;


import kr.co.cms.domain.cca.entity.CoreCptEval;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoreCptEvalRepository extends JpaRepository<CoreCptEval, String> {

}
