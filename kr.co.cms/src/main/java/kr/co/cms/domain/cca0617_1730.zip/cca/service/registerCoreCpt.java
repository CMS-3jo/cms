package kr.co.cms.domain.cca.service;

public class registerCoreCpt {

}
